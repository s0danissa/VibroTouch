# generated from catkin/cmake/template/cfg-extras.context.py.in
DEVELSPACE = 'FALSE' == 'TRUE'
INSTALLSPACE = 'TRUE' == 'TRUE'

CATKIN_DEVEL_PREFIX = '/home/danissa/catkin_ws_403/devel'

CATKIN_GLOBAL_BIN_DESTINATION = 'bin'
CATKIN_GLOBAL_ETC_DESTINATION = 'etc'
CATKIN_GLOBAL_INCLUDE_DESTINATION = 'include'
CATKIN_GLOBAL_LIB_DESTINATION = 'lib'
CATKIN_GLOBAL_LIBEXEC_DESTINATION = 'lib'
CATKIN_GLOBAL_PYTHON_DESTINATION = 'lib/python2.7/dist-packages'
CATKIN_GLOBAL_SHARE_DESTINATION = 'share'

CATKIN_PACKAGE_BIN_DESTINATION = 'lib/rosserial_arduino'
CATKIN_PACKAGE_ETC_DESTINATION = 'etc/rosserial_arduino'
CATKIN_PACKAGE_INCLUDE_DESTINATION = 'include/rosserial_arduino'
CATKIN_PACKAGE_LIB_DESTINATION = 'lib'
CATKIN_PACKAGE_LIBEXEC_DESTINATION = 'lib/rosserial_arduino'
CATKIN_PACKAGE_PYTHON_DESTINATION = 'lib/python2.7/dist-packages/rosserial_arduino'
CATKIN_PACKAGE_SHARE_DESTINATION = 'share/rosserial_arduino'

CMAKE_BINARY_DIR = '/home/danissa/catkin_ws_403/src'
CMAKE_CURRENT_BINARY_DIR = '/home/danissa/catkin_ws_403/src/rosserial/rosserial_arduino'
CMAKE_CURRENT_SOURCE_DIR = '/home/danissa/catkin_ws_403/src/rosserial/rosserial_arduino'
CMAKE_INSTALL_PREFIX = '/home/danissa/catkin_ws_403/install'
CMAKE_SOURCE_DIR = '/home/danissa/catkin_ws_403/src'

PKG_CMAKE_DIR = '${rosserial_arduino_DIR}'

PROJECT_NAME = 'rosserial_arduino'
PROJECT_BINARY_DIR = '/home/danissa/catkin_ws_403/src/rosserial/rosserial_arduino'
PROJECT_SOURCE_DIR = '/home/danissa/catkin_ws_403/src/rosserial/rosserial_arduino'
