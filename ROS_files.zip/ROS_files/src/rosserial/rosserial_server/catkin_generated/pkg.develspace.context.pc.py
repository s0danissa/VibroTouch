# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/danissa/catkin_ws_403/src/rosserial/rosserial_server/include".split(';') if "/home/danissa/catkin_ws_403/src/rosserial/rosserial_server/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rosserial_msgs;std_msgs;topic_tools".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lrosserial_server_lookup".split(';') if "-lrosserial_server_lookup" != "" else []
PROJECT_NAME = "rosserial_server"
PROJECT_SPACE_DIR = "/home/danissa/catkin_ws_403/devel"
PROJECT_VERSION = "0.9.2"
