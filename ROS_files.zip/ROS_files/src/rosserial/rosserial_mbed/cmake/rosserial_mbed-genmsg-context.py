# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/danissa/catkin_ws_403/src/rosserial/rosserial_mbed/msg/Adc.msg"
services_str = "/home/danissa/catkin_ws_403/src/rosserial/rosserial_mbed/srv/Test.srv"
pkg_name = "rosserial_mbed"
dependencies_str = ""
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "rosserial_mbed;/home/danissa/catkin_ws_403/src/rosserial/rosserial_mbed/msg"
PYTHON_EXECUTABLE = "/usr/bin/python2"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/kinetic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
