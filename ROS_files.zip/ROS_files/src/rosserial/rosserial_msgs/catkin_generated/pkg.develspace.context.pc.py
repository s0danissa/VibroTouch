# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/danissa/catkin_ws_403/devel/include".split(';') if "/home/danissa/catkin_ws_403/devel/include" != "" else []
PROJECT_CATKIN_DEPENDS = "message_runtime".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "rosserial_msgs"
PROJECT_SPACE_DIR = "/home/danissa/catkin_ws_403/devel"
PROJECT_VERSION = "0.9.2"
